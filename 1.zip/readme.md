# Restaurant Management System
2nd year 2nd Sem ITP.


**Guide Lines**

1. install the laragon
2. open the vs code(or any other text editor) and clone the github project.
3. use the  "C:\laragon\www" directory as the local respository.
  ex: "C:\laragon\www\ITP-GitHub"
4. Download and install the composer. https://getcomposer.org/Composer-Setup.exe
5. After open the project successfully run this command "composer install" using the text editor's(ex: vs code, atom, etc..) inbuilt          terminal.then it will install all dependencies for the project.
6. finally use this command "php artisan serve" to run your project inside the web browser.
