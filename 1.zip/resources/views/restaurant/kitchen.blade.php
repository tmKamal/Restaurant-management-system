@extends('layouts.admin')
@section('content')

    <h2>this is kitchen</h2>
@endsection
