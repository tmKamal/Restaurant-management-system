**Guideline for contributing**

1)Create new branch for your contribution
2)Don't push directly to the -master, use your branch to push
3)Then create a pull request
