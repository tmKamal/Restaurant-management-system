<?php $__env->startSection('content'); ?>
<!--form-->
<div class="col-md-8 div-center">
    <h1>Hi!! <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastName); ?></h1>
    <h3>Welcome to the Control Panel.</h3>
    <h4> Position: <?php echo e(Auth::user()->type); ?></h4>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/restaurant/admin_panel/index.blade.php ENDPATH**/ ?>