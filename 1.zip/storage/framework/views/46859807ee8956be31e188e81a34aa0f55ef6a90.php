<?php $__env->startSection('content'); ?>
<!--form-->
<form id="loginForm" method="POST">
    <div class="login-title mb-3">
        Login
    </div>
     <?php echo csrf_field(); ?>
    <div class="input-group">
        <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroupPrepend"><i class="material-icons">account_circle</i></span>
        </div>
        <input id="email" name="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" value="<?php echo e(old('email')); ?>" aria-describedby="inputGroupPrepend" required autocomplete="email" autofocus>
        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="input-group mb-3 mt-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroupPrepend"><i class="material-icons">lock</i>
        </div>
        <input id="password" name="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" aria-describedby="inputGroupPrepend" required autocomplete="current-password">
        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="custom-control custom-checkbox mr-sm-2 mb-1">
        <input name="remember" id="remember" type="checkbox" class="custom-control-input" <?php echo e(old('remember')?'checked':''); ?>>
        <label class="custom-control-label" for="remember">Remember Me</label>
    </div>
    <?php if(Route::has('password.request')): ?>
    <div class="form-group">
        <a href="#" onclick="document.getElementById('loginForm').submit()" class="loginButton mb-1">LOGIN</a>
        <div class="forgot-pass ">
        <h6>Forgot <a href="<?php echo e(route('password.request')); ?>">Password?</a></h6>
        </div>
    </div>
    <?php endif; ?>

    <hr>
    <div class="form-group">

        <div class="forgot-pass mt-4">
        <h6>Don't have an account? <a href="<?php echo e(route('register')); ?>" class="ml-2">Sign Up Here!</a></h6>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.loginform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/auth/login.blade.php ENDPATH**/ ?>